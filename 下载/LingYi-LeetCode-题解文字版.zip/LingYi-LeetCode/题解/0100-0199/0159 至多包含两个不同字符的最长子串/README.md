# 159. 至多包含两个不同字符的最长子串

[力扣原题](https://leetcode.cn/problems/longest-substring-with-at-most-two-distinct-characters/)

所在刷题路径：灵神题单·滑动窗口与双指针

| 作者 | 题解 | 动画讲解 |
|---|---|---|
| 灵茶山艾府 | — | — |
| yiduobo | [📄 题解](yiduobo.md) | [▶︎ 动画（GIF）](0159%20至多包含两个不同字符的最长子串%20·%20yiduobo.gif) · [mp4 文件](0159%20至多包含两个不同字符的最长子串%20·%20yiduobo.mp4) |

## 动画讲解

> 动图会循环播放；想暂停、拖进度条请下载上面表格里的 mp4 文件。

### yiduobo

![0159 至多包含两个不同字符的最长子串 · yiduobo](0159%20至多包含两个不同字符的最长子串%20·%20yiduobo.gif)


---
[↑ 返回 0100-0199](../README.md) · [总索引](../../../索引.md) · [仓库首页](../../../README.md)
