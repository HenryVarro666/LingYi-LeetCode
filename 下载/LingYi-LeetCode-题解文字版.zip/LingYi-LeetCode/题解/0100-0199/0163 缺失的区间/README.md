# 163. 缺失的区间

[力扣原题](https://leetcode.cn/problems/missing-ranges/)

| 作者 | 题解 | 动画讲解 |
|---|---|---|
| 灵茶山艾府 | — | — |
| yiduobo | [📄 题解](yiduobo.md) | [▶︎ 动画（GIF）](0163%20缺失的区间%20·%20yiduobo.gif) · [mp4 文件](0163%20缺失的区间%20·%20yiduobo.mp4) |

## 动画讲解

> 动图会循环播放；想暂停、拖进度条请下载上面表格里的 mp4 文件。

### yiduobo

![0163 缺失的区间 · yiduobo](0163%20缺失的区间%20·%20yiduobo.gif)


---
[↑ 返回 0100-0199](../README.md) · [总索引](../../../索引.md) · [仓库首页](../../../README.md)
